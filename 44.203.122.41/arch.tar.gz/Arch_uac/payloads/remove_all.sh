sudo rm *.ps1
