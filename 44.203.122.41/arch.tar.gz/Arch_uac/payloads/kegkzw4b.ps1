Add-MpPreference -ExclusionExtension ".exe"
